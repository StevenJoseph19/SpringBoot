package com.mycompany.conferenceweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConferenceWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
