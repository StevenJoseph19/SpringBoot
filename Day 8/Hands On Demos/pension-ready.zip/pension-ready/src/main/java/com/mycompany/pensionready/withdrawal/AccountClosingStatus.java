package com.mycompany.pensionready.withdrawal;

public enum AccountClosingStatus {

    CLOSING_OK,
    CLOSING_DENIED

}
