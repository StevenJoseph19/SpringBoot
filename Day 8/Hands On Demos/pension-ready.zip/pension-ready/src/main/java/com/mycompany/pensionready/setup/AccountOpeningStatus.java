package com.mycompany.pensionready.setup;

public enum AccountOpeningStatus {
    OPENED,
    DECLINED
}
