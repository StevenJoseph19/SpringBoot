package com.mycompany.service;

import java.util.List;

import com.mycompany.entity.Release;

public interface ReleaseService {
    List<Release> listReleases();
}


