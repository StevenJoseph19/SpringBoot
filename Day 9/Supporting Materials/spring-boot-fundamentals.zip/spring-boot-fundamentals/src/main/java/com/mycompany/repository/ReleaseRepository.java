package com.mycompany.repository;

import org.springframework.data.repository.CrudRepository;

import com.mycompany.entity.Release;

public interface ReleaseRepository extends CrudRepository<Release, Long> {
}