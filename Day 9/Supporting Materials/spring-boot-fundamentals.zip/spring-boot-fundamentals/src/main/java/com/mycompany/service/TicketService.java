package com.mycompany.service;

import java.util.List;

import com.mycompany.entity.Ticket;

public interface TicketService {
    List<Ticket> listTickets();
}


