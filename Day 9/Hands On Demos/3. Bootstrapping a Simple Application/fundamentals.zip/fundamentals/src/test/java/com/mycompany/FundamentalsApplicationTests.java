package com.mycompany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundamentalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
