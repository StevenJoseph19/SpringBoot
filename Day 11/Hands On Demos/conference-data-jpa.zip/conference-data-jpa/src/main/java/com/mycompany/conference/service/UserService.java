package com.mycompany.conference.service;

import com.mycompany.conference.model.User;

public interface UserService {

	User save(User user);

}